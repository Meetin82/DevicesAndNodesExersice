<template>
  <div>
    <h1>Устройства</h1>
    <DeviceList />
  </div>
</template>

<script>
import DeviceList from './components/DeviceList.vue';

export default {
  components: {
    DeviceList
  }
};
</script>