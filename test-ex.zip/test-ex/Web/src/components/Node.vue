<template>
  <li>
    <div v-if="!node.isEditing">
      <span>{{ node.name }}</span>
      <button @click="editNode">Редактировать</button>
      <button @click="$emit('delete')">Удалить</button>
    </div>
    <div v-else>
      <input v-model="node.name" @blur="saveNode" type="text" />
      <button @click="saveNode">Сохранить</button>
    </div>
  </li>
</template>

<script>
export default {
  props: {
    node: Object
  },
  methods: {
    editNode() {
      this.node.isEditing = true;
    },
    saveNode() {
      this.node.isEditing = false;
    }
  }
};
</script>
