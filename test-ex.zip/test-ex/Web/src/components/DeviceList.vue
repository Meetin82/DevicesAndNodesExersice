<template>
    <div>
      <button @click="showAddDevice = true">Добавить устройство</button>
      
      <ul>
        <Device
          v-for="(device, index) in devices"
          :key="device.id"
          :device="device"
          @edit="editDevice(index)"
          @delete="deleteDevice(index)"
          @add-node="addNode(index)"
          @edit-node="editNode(index, $event.nodeIndex)"
          @delete-node="deleteNode(index, $event.nodeIndex)"
        />
      </ul>
  
      <div v-if="showAddDevice">
        <input
            v-model="newDeviceName"
            placeholder="Название устройства"
            type="text"
        />
        <button @click="addDevice">Сохранить устройство</button>
        <button @click="showAddDevice = false">Отменить</button>
      </div>
    </div>
  </template>
  
  <script>
  import { ref } from 'vue';
  import Device from './Device.vue';
  
  export default {
    components: {
      Device
    },
    setup() {
      const devices = ref([]);
      const newDeviceName = ref('');
      const showAddDevice = ref(false);
  
      const addDevice = () => {
        if (newDeviceName.value) {
          devices.value.push({
            id: Date.now(),
            name: newDeviceName.value,
            nodes: [],
            showNodes: false,
            isEditing: false
          });
          newDeviceName.value = '';
          showAddDevice.value = false;
        }
      };
  
      const deleteDevice = (index) => {
        devices.value.splice(index, 1);
      };
  
      const editDevice = (index) => {
        devices.value[index].isEditing = true;
      };
  
      const addNode = (deviceIndex) => {
        if (newNodeName.value) {
          devices.value[deviceIndex].nodes.push({
            id: Date.now(),
            name: newNodeName.value,
            isEditing: false
          });
          newNodeName.value = '';
          showAddNode.value = false;
        }
      };

  
      const deleteNode = (deviceIndex, nodeIndex) => {
        devices.value[deviceIndex].nodes.splice(nodeIndex, 1);
      };
  
      const editNode = (deviceIndex, nodeIndex) => {
        devices.value[deviceIndex].nodes[nodeIndex].isEditing = true;
      };

      return {
        devices,
        newDeviceName,
        showAddDevice,
        addDevice,
        deleteDevice,
        editDevice,
        addNode,
        deleteNode,
        editNode
      };
    }
  };
  </script>
  