<template>
  <li>
    <div v-if="!device.isEditing">
      <span>{{ device.name }}</span>
      <button @click="$emit('edit')">Редактировать</button>
      <button @click="$emit('delete')">Удалить</button>
      <button @click="device.showNodes = !device.showNodes">Узлы</button>
    </div>
    <div v-else>
      <input v-model="device.name" @blur="saveDevice" type="text" />
      <button @click="saveDevice">Сохранить</button>
    </div>
    <div v-if="device.showNodes">
      <h3>Узлы устройства</h3>
      <ul>
        <li v-for="(node, index) in device.nodes" :key="node.id">
          <div class="move-buttons">
            <button @click="moveNode(index, -1)" :disabled="index === 0">↑</button>
            <button @click="moveNode(index, 1)" :disabled="index === device.nodes.length - 1">↓</button>
          </div>
          <Node
            :node="node"
            @delete="deleteNode(index)"
          />
        </li>
      </ul>
      <div v-if="!showAddNode">
        <button @click="showAddNode = true">Добавить узел</button>
      </div>
      <div v-if="showAddNode">
        <input v-model="newNodeName" placeholder="Название узла" type="text" />
        <button @click="addNode">Сохранить узел</button>
      </div>
    </div>
  </li>
</template>

<script>
import Node from './Node.vue';

export default {
  components: {
    Node
  },
  props: {
    device: Object
  },
  data() {
    return {
      newNodeName: '',
      showAddNode: false
    };
  },
  methods: {
    saveDevice() {
      this.device.isEditing = false;
    },
    addNode() {
      if (this.newNodeName) {
        this.device.nodes.push({
          id: Date.now(),
          name: this.newNodeName,
          isEditing: false
        });
        this.newNodeName = '';
        this.showAddNode = false;
      }
    },
    deleteNode(nodeIndex) {
      this.$emit('delete-node', { nodeIndex });
    },
    moveNode(index, direction) {
      const newIndex = index + direction;
      if (newIndex >= 0 && newIndex < this.device.nodes.length) {
        const nodeToMove = this.device.nodes.splice(index, 1)[0];
        this.device.nodes.splice(newIndex, 0, nodeToMove);
      }
    }
  }
};
</script>

<style scoped>
button {
  margin-left: 5px;
}

.move-buttons {
  display: inline-block;
  margin-right: 10px;
}
</style>
